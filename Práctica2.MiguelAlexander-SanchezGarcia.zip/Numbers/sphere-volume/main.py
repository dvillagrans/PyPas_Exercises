# E S C O M  -  I P N 
# D A A D
# 4AV1
# September 27°, 2024
# @autor: Miguel Alexander Sanchez García

def run(radius: float) -> float:
    PI = 3.14
    volume = (4/3) * PI * (radius ** 3)
    return volume


# DO NOT TOUCH THE CODE BELOW
if __name__ == '__main__':
    import vendor

    vendor.launch(run)

# Developed by MASG