# E S C O M  -  I P N 
# D A A D
# 4AV1
# September 27°, 2024
# @autor: Miguel Alexander Sanchez García

def run(current_pos: int, dice: int) -> int:
    distance = dice * 2
    final_pos = current_pos + distance
    return final_pos


# DO NOT TOUCH THE CODE BELOW
if __name__ == '__main__':
    import vendor

    vendor.launch(run)

# Developed by MASG